<?php $__env->startSection('title', 'Placements'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header py-3">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-briefcase me-2 text-primary"></i>
                    <span class="fw-semibold">Placement Management</span>
                </h5>
                <?php if(auth()->user()->isAdmin() || auth()->user()->isTrainer()): ?>
                <a href="<?php echo e(route('placements.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-2"></i>Add New Placement
                </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-body">
            <!-- Search and Filters -->
            <div class="row g-3 mb-4">
                <div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-text border-end-0 bg-white">
                            <i class="fas fa-search text-muted"></i>
                        </span>
                        <input type="text" 
                               id="searchInput" 
                               class="form-control border-start-0" 
                               placeholder="Search placements..."
                               value="<?php echo e(request('search')); ?>">
                    </div>
                </div>

                <div class="col-md-4">
                    <select id="batchFilter" class="form-select">
                        <option value="">All Companies</option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($company); ?>" <?php echo e(request('company') == $company ? 'selected' : ''); ?>>
                                <?php echo e($company); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <!-- Placements Table -->
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 5%;">#</th>
                            <th style="width: 20%;">Student Details</th>
                            <th style="width: 20%;">Company Info</th>
                            <th style="width: 15%;">Designation</th>
                            <th style="width: 15%;">Salary</th>
                            <th style="width: 10%;">Joining Date</th>
                            <th class="text-center" style="width: 15%;">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="border-top">
                        <?php $__empty_1 = true; $__currentLoopData = $placements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center text-muted"><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle bg-light me-3 d-flex align-items-center justify-content-center"
                                             style="width: 40px; height: 40px;">
                                            <i class="fas fa-user text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="fw-medium"><?php echo e($placement->name); ?></div>
                                            <small class="text-muted">
                                                <i class="fas fa-layer-group me-1"></i>
                                                Batch <?php echo e($placement->batch_no); ?>

                                            </small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-building me-2 text-primary"></i>
                                        <div class="fw-medium"><?php echo e($placement->company_name); ?></div>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-medium"><?php echo e($placement->designation); ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-success-subtle text-success">
                                        ₹<?php echo e($placement->salary); ?>

                                    </span>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <i class="far fa-calendar me-1"></i>
                                        <?php echo e($placement->joining_date->format('d M Y')); ?>

                                    </small>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">
                                        <a href="<?php echo e(route('placements.show', ['placedStudent' => $placement])); ?>" 
                                           class="btn btn-sm btn-outline-primary"
                                           title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if(auth()->user()->isAdmin() || auth()->user()->isTrainer()): ?>
                                            <a href="<?php echo e(route('placements.edit', ['placedStudent' => $placement])); ?>" 
                                               class="btn btn-sm btn-outline-info"
                                               title="Edit Placement">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('placements.destroy', ['placedStudent' => $placement])); ?>" 
                                                  method="POST" 
                                                  class="d-inline"
                                                  onsubmit="return confirm('Are you sure you want to delete this placement?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger"
                                                        title="Delete Placement">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <div class="text-muted">
                                        <i class="fas fa-briefcase fa-3x mb-3"></i>
                                        <p class="mb-1">No placements found</p>
                                        <small>Try adjusting your search criteria</small>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if($placements->hasPages()): ?>
            <div class="d-flex justify-content-end mt-4">
                <?php echo e($placements->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .table th {
        font-weight: 600;
        color: #6b7280;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.05em;
    }
    
    .btn-group .btn {
        padding: 0.25rem 0.5rem;
    }
    
    .btn-group .btn:hover {
        transform: translateY(-1px);
        transition: transform 0.2s;
    }
    
    .table-hover tbody tr:hover {
        background-color: #f8fafc;
    }
    
    .badge {
        font-weight: 500;
        padding: 0.5em 0.75em;
    }
    
    .bg-primary-subtle {
        background-color: #e0f2fe !important;
    }
    
    .text-primary {
        color: #2563eb !important;
    }
    
    .bg-success-subtle {
        background-color: #dcfce7 !important;
    }
    
    .text-success {
        color: #059669 !important;
    }
    
    .bg-warning-subtle {
        background-color: #fef3c7 !important;
    }
    
    .text-warning {
        color: #d97706 !important;
    }
    
    .bg-info-subtle {
        background-color: #e0f2fe !important;
    }
    
    .text-info {
        color: #0891b2 !important;
    }

    .bg-danger-subtle {
        background-color: #fee2e2 !important;
    }
    
    .text-danger {
        color: #dc2626 !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php if(session('success')): ?>
    <?php $__env->startPush('scripts'); ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: "<?php echo e(session('success')); ?>",
            showConfirmButton: false,
            timer: 3000
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let searchTimeout;
    const searchInput = document.getElementById('searchInput');
    const batchFilter = document.getElementById('batchFilter');

    function updateFilters() {
        const searchQuery = searchInput.value;
        const companyQuery = batchFilter.value;

        const params = new URLSearchParams(window.location.search);
        if (searchQuery) params.set('search', searchQuery);
        else params.delete('search');
        if (companyQuery) params.set('company', companyQuery);
        else params.delete('company');

        window.location.href = `${window.location.pathname}?${params.toString()}`;
    }

    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(updateFilters, 500);
    });

    batchFilter.addEventListener('change', updateFilters);
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HopeBajaj\resources\views/placements/index.blade.php ENDPATH**/ ?>