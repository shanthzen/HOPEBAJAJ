<?php $__env->startSection('content'); ?>
<style>
    .activity-logs {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }

    .section-header {
        background: var(--primary-color);
        padding: 2rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .section-title {
        color: white;
        font-size: 1.5rem;
        font-weight: 600;
        margin-bottom: 0;
    }

    .log-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        margin-bottom: 1rem;
        overflow: hidden;
    }

    .log-header {
        background: var(--accent-color);
        padding: 1rem;
        border-bottom: 1px solid #e5e7eb;
    }

    .log-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--text-primary);
        margin-bottom: 0.5rem;
    }

    .log-meta {
        display: flex;
        gap: 2rem;
        color: var(--text-secondary);
        font-size: 0.9rem;
    }

    .log-meta-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .log-meta-item i {
        color: var(--primary-color);
        width: 16px;
    }

    .log-content {
        padding: 1rem;
    }

    .log-details {
        background: #f8fafc;
        padding: 1rem;
        border-radius: 6px;
        margin-top: 1rem;
    }

    .log-details pre {
        margin: 0;
        white-space: pre-wrap;
        word-wrap: break-word;
    }

    .log-details-title {
        font-weight: 600;
        color: var(--text-primary);
        margin-bottom: 0.5rem;
    }

    .log-details-item {
        margin-bottom: 0.5rem;
        display: flex;
        gap: 0.5rem;
    }

    .log-details-label {
        font-weight: 500;
        color: var(--text-secondary);
        min-width: 120px;
    }

    .log-details-value {
        color: var(--text-primary);
    }

    .action-create {
        color: #059669;
    }

    .action-update {
        color: #0284c7;
    }

    .action-delete {
        color: #dc2626;
    }

    .empty-state {
        text-align: center;
        padding: 4rem 2rem;
        background: var(--accent-color);
        border-radius: 10px;
    }

    .empty-icon {
        font-size: 4rem;
        color: var(--primary-color);
        opacity: 0.5;
        margin-bottom: 1rem;
    }

    .empty-title {
        font-size: 1.5rem;
        color: var(--text-primary);
        margin-bottom: 0.5rem;
    }

    .empty-description {
        color: var(--text-secondary);
        margin-bottom: 2rem;
    }
</style>

<div class="activity-logs">
    <div class="section-header">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="section-title">
                <i class="fas fa-history me-2"></i>Activity Logs
            </h2>
            <a href="<?php echo e(route('activity-logs.export')); ?>" class="btn btn-light">
                <i class="fas fa-download me-2"></i>Export Logs
            </a>
        </div>

        <form action="<?php echo e(route('activity-logs.index')); ?>" method="GET" class="bg-white p-3 rounded-3">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Action Type</label>
                    <select name="action" class="form-select">
                        <option value="">All Actions</option>
                        <option value="create" <?php echo e(request('action') === 'create' ? 'selected' : ''); ?>>Create</option>
                        <option value="update" <?php echo e(request('action') === 'update' ? 'selected' : ''); ?>>Update</option>
                        <option value="delete" <?php echo e(request('action') === 'delete' ? 'selected' : ''); ?>>Delete</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Model Type</label>
                    <select name="model_type" class="form-select">
                        <option value="">All Models</option>
                        <?php $__currentLoopData = $modelTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type); ?>" <?php echo e(request('model_type') === $type ? 'selected' : ''); ?>>
                                <?php echo e(class_basename($type)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Start Date</label>
                    <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">End Date</label>
                    <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Search Text</label>
                    <input type="text" name="search" class="form-control" placeholder="Search in details..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">User</label>
                    <select name="user_id" class="form-select">
                        <option value="">All Users</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-12 text-end">
                    <a href="<?php echo e(route('activity-logs.index')); ?>" class="btn btn-secondary me-2">
                        <i class="fas fa-undo me-2"></i>Reset
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search me-2"></i>Search
                    </button>
                </div>
            </div>
        </form>
    </div>

    <?php if($logs->count() > 0): ?>
        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="log-card">
                <div class="log-header">
                    <div class="log-title">
                        <i class="fas fa-<?php echo e($log->action === 'create' ? 'plus-circle' : ($log->action === 'update' ? 'edit' : 'trash')); ?> 
                           action-<?php echo e($log->action); ?> me-2"></i>
                        <?php echo e(ucfirst($log->action)); ?> <?php echo e(class_basename($log->model_type)); ?>

                    </div>
                    <div class="log-meta">
                        <div class="log-meta-item">
                            <i class="fas fa-user"></i>
                            <?php echo e($log->user->name); ?>

                        </div>
                        <div class="log-meta-item">
                            <i class="fas fa-calendar"></i>
                            <?php echo e($log->created_at->format('d-m-Y H:i:s')); ?>

                        </div>
                        <div class="log-meta-item">
                            <i class="fas fa-network-wired"></i>
                            <?php echo e($log->ip_address); ?>

                        </div>
                    </div>
                </div>

                <div class="log-content">
                    <div class="log-details">
                        <div class="log-details-item">
                            <span class="log-details-label">Model Type:</span>
                            <span class="log-details-value"><?php echo e(class_basename($log->model_type)); ?></span>
                        </div>
                        <div class="log-details-item">
                            <span class="log-details-label">Model ID:</span>
                            <span class="log-details-value"><?php echo e($log->model_id); ?></span>
                        </div>
                        
                        <?php if($log->details): ?>
                            <?php if($log->action === 'delete' && isset($log->details['deleted_model'])): ?>
                                <div class="log-details-title mt-3">Deleted Model Details:</div>
                                <?php $__currentLoopData = $log->details['deleted_model']['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="log-details-item">
                                        <span class="log-details-label"><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:</span>
                                        <span class="log-details-value"><?php echo e(is_array($value) ? json_encode($value) : $value); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php elseif($log->action === 'update' && isset($log->details['changed'])): ?>
                                <div class="log-details-title mt-3">Changed Fields:</div>
                                <?php $__currentLoopData = $log->details['changed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="log-details-item">
                                        <span class="log-details-label"><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:</span>
                                        <span class="log-details-value">
                                            From: <?php echo e($log->details['original'][$key] ?? 'null'); ?>

                                            <i class="fas fa-arrow-right mx-2"></i>
                                            To: <?php echo e($value); ?>

                                        </span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php elseif($log->action === 'create' && isset($log->details['attributes'])): ?>
                                <div class="log-details-title mt-3">Created With:</div>
                                <?php $__currentLoopData = $log->details['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="log-details-item">
                                        <span class="log-details-label"><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:</span>
                                        <span class="log-details-value"><?php echo e(is_array($value) ? json_encode($value) : $value); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex justify-content-center mt-4">
            <?php echo e($logs->links()); ?>

        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-history empty-icon"></i>
            <h3 class="empty-title">No Activity Logs</h3>
            <p class="empty-description">There are no activity logs recorded yet.</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HopeBajaj\resources\views/activity-logs/index.blade.php ENDPATH**/ ?>